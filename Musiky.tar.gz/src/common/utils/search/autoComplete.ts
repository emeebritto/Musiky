import { istatic } from 'services';


interface FCParams {
  input:string;
  maxResult:number;
};

const autoComplete = async({ input, maxResult=1 }:FCParams): Promise<string[] | []> => {
  if (input.length < 1) return [];

  const musicTitles:string[] = await istatic
    .musicsData({ onlyTitle: 1, searchTitle: input })
    .then(r => r.data.map(music => music.title));

  const artistsNames:string[] = await istatic
    .artistsData({ onlyNames: 1, searchName: input })
    .then(r => r.data.map(artist => artist.name));

  return [ ...musicTitles, ...artistsNames ];
}

export default autoComplete;
