import faker from 'faker';
import { ArtistDataProps, Music } from 'common/types';
import { istatic } from 'services';


interface SearchReturn {
  input:string;
  requestId:string;
  noFound:boolean;
  searchTop:ArtistDataProps | {};
  artists:ArtistDataProps[] | [];
  musics:Music[] | [];
}

const search = async({ input }:{ input:string }): Promise<SearchReturn> => {

  const result:SearchReturn = {
    input: input,
    requestId: faker.datatype.uuid(),
    noFound: false,
    searchTop: {},
    artists: [],
    musics: []
  };

  const artists = await istatic
    .artistsData({ searchName: input })
    .then(r => r.data);

  if (!artists || !artists.length) {
    result.noFound = true;
    return result;
  }

  result.searchTop = artists[0];
  result.artists = artists;
  result.musics = await istatic
    .musicsData({ filter: `artists:${artists[0].name}` })
    .then(r => r.data);

  return result;
}

export default search;
