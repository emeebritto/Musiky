import faker from 'faker';
import { istatic } from 'services';

const randomSongs = async({ maxResult=6 }:{ maxResult:number }) => {
  const musics = await istatic.musicsData({
    random: 1,
    maxResult: maxResult,
    filter: 'tags:music'
  }).then(r => r.data);

  return {
    id: faker.datatype.uuid(),
    list: musics
  };
}

export default randomSongs;
