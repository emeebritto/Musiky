import loadingBar from './transitionLoadingBar'
export default loadingBar;