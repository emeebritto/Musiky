import playerControl from './playerControl'
export default playerControl;